package demo;

public class Simple {

	public Simple() {
		System.out.println("Simple Constructor ");
	}
	public void m1() {
		System.out.println("m1 invoked ...");
	}
}
