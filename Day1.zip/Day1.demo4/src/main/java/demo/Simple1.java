package demo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class Simple1 {

	public Simple1() {
		System.out.println("Simple1 Constructor ");
	}
	public void m1() {
		System.out.println("m1 invoked of Simple1 ...");
	}
}
