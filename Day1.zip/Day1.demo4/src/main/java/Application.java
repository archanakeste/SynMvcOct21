import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import demo.Simple;
import demo.Simple1;
import demo1.Connection;
import demo1.DeptDAO;
import demo1.OracleConnection;

@Configuration
@ComponentScan(basePackages = "demo,demo1")
public class Application {
	@Bean()
	@Scope(value = "prototype")
	public Simple simple()
	{
		System.out.println("in getsimple of Application");
		return new Simple();
	}
	public static void main(String[] args) {
			ApplicationContext ctx = new AnnotationConfigApplicationContext(Application.class);
			System.out.println("---------------------Context Loaded-----------------------");
			String[] arr = ctx.getBeanDefinitionNames();
			for (String string : arr) {
				System.out.println(string);
			}
			System.out.println("-----------------------------");
			DeptDAO dao = ctx.getBean("deptdao", DeptDAO.class);
	/*	 setter injection	
	 * Connection con = ctx.getBean("ora",OracleConnection.class);
			dao.setCon(con);
	*/	
			dao.insert();
			
			
/*			
			Simple s1 = ctx.getBean("simple", Simple.class);
			s1.m1();
			Simple s2 = ctx.getBean("simple", Simple.class);
			s2.m1();
			Simple1 s11 = ctx.getBean("simple1", Simple1.class);
			s11.m1();
*/			
	}

}
