package demo1;

import org.springframework.stereotype.Component;

@Component(value = "sql")
public class SQLConnection implements Connection{

	public SQLConnection() {
		System.out.println("SQLConnection Constructor");
	}
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Open method of SQLConnection invoked ");
	}

	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Close method of SQLConnection invoked ");
	}

}
