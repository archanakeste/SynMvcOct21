package demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import demo1.Connection;

@ComponentScan(basePackages = "demo,demo1")
@Configuration
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	ApplicationContext ctx = new ClassPathXmlApplicationContext("demo1.xml");
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Application.class);
		System.out.println("----------------Context Loaded---------------------");
		//Simple s1 =new Simple();
		Simple s1 = ctx.getBean("simple",Simple.class);
		s1.m1();
		Simple s2 = ctx.getBean("simple",Simple.class);
		s2.m1();
		Connection con  = ctx.getBean("sql", Connection.class);
		con.open();
		con.close();
	}

}
